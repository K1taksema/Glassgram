# Glassgram

Android-клієнт Telegram у стилі «рідке скло». Етап 1: вхід (номер → код → пароль) і список чатів.
Зараз працює демо-репозиторій (`FakeTelegramRepository`, код підтвердження 12345).
Справжній Telegram підключається реалізацією `TelegramRepository` на TDLib.

## Як отримати APK
- Android Studio: відкрити папку, Build > Build APK(s) → app/build/outputs/apk/debug/app-debug.apk
- Без Android Studio: завантажити проєкт у GitHub-репозиторій (гілка main), вкладка Actions → Build APK → артефакт glassgram-debug-apk
