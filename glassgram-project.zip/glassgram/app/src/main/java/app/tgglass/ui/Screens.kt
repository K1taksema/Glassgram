package app.tgglass.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import app.tgglass.data.AuthState
import app.tgglass.data.Chat

@Composable
fun App(vm: AppViewModel = viewModel()) {
    val auth by vm.auth.collectAsState()
    val chats by vm.chats.collectAsState()

    LiquidBackground {
        AnimatedContent(
            targetState = auth,
            contentKey = { it::class },
            transitionSpec = { fadeIn(tween(350)) togetherWith fadeOut(tween(200)) },
            label = "screen",
        ) { state ->
            if (state is AuthState.Ready) {
                ChatListScreen(chats = chats, onLogout = vm::logOut)
            } else {
                LoginScreen(
                    state = state,
                    busy = vm.busy,
                    error = vm.error,
                    onPhone = vm::submitPhone,
                    onCode = vm::submitCode,
                    onPassword = vm::submitPassword,
                )
            }
        }
    }
}

@Composable
fun LoginScreen(
    state: AuthState,
    busy: Boolean,
    error: String?,
    onPhone: (String) -> Unit,
    onCode: (String) -> Unit,
    onPassword: (String) -> Unit,
) {
    var phone by rememberSaveable { mutableStateOf("+380") }
    var code by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        GlassOrb()
        Spacer(Modifier.height(28.dp))

        val title: String
        val hint: String
        when (state) {
            is AuthState.Code -> {
                title = "Введіть код"
                hint = "Код надіслано в Telegram на ${state.phone}"
            }
            AuthState.Password -> {
                title = "Пароль"
                hint = "Акаунт захищено паролем двоетапної перевірки"
            }
            else -> {
                title = "Вхід у Telegram"
                hint = "Вкажіть номер телефону в міжнародному форматі"
            }
        }
        Text(
            title, color = Palette.Text, fontSize = 30.sp,
            fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp,
        )
        Spacer(Modifier.height(8.dp))
        Text(hint, color = Palette.TextDim, fontSize = 15.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(28.dp))

        when (state) {
            is AuthState.Code -> GlassField(
                value = code,
                onValueChange = { code = it.filter(Char::isDigit).take(6) },
                placeholder = "Код",
                keyboardType = KeyboardType.Number,
                onDone = { onCode(code) },
            )
            AuthState.Password -> GlassField(
                value = password,
                onValueChange = { password = it },
                placeholder = "Пароль",
                keyboardType = KeyboardType.Password,
                visual = PasswordVisualTransformation(),
                onDone = { onPassword(password) },
            )
            else -> GlassField(
                value = phone,
                onValueChange = { phone = it.filter { c -> c.isDigit() || c == '+' }.take(16) },
                placeholder = "Номер телефону",
                keyboardType = KeyboardType.Phone,
                onDone = { onPhone(phone) },
            )
        }

        if (error != null) {
            Spacer(Modifier.height(12.dp))
            Text(error, color = Palette.Rose, fontSize = 14.sp, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(20.dp))

        GlassButton(
            text = when (state) {
                is AuthState.Code -> "Увійти"
                AuthState.Password -> "Підтвердити"
                else -> "Далі"
            },
            loading = busy,
            onClick = {
                when (state) {
                    is AuthState.Code -> onCode(code)
                    AuthState.Password -> onPassword(password)
                    else -> onPhone(phone)
                }
            },
        )

        if (state is AuthState.Code) {
            Spacer(Modifier.height(16.dp))
            Text("Демо-режим: код 12345", color = Palette.TextDim, fontSize = 13.sp)
        }
    }
}

@Composable
fun ChatListScreen(chats: List<Chat>, onLogout: () -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    var unreadOnly by rememberSaveable { mutableStateOf(false) }

    val visible = chats
        .filter { !unreadOnly || it.unread > 0 }
        .filter { query.isBlank() || it.title.contains(query.trim(), ignoreCase = true) }
        .sortedByDescending { it.pinned }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 24.dp, end = 20.dp, top = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "Чати", color = Palette.Text, fontSize = 34.sp,
                fontWeight = FontWeight.Bold, letterSpacing = (-0.8).sp,
                modifier = Modifier.weight(1f),
            )
            Text(
                "Вийти", color = Palette.Text, fontSize = 14.sp,
                modifier = Modifier
                    .glass(RoundedCornerShape(50))
                    .clickable(onClick = onLogout)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
            )
        }
        Spacer(Modifier.height(14.dp))
        GlassField(
            value = query,
            onValueChange = { query = it },
            placeholder = "Пошук",
            modifier = Modifier.padding(horizontal = 16.dp),
            imeAction = androidx.compose.ui.text.input.ImeAction.Search,
        )
        Spacer(Modifier.height(12.dp))
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterPill("Усі", selected = !unreadOnly) { unreadOnly = false }
            FilterPill("Непрочитані", selected = unreadOnly) { unreadOnly = true }
        }
        Spacer(Modifier.height(8.dp))

        if (visible.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                Text(
                    if (unreadOnly) "Непрочитаних чатів немає" else "Нічого не знайдено. Спробуйте інший запит",
                    color = Palette.TextDim, fontSize = 16.sp, textAlign = TextAlign.Center,
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.navigationBarsPadding(),
            ) {
                items(visible, key = { it.id }) { chat -> ChatRow(chat) }
            }
        }
    }
}

@Composable
private fun FilterPill(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Text(
        text,
        color = Palette.Text,
        fontSize = 14.sp,
        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
        modifier = Modifier
            .clip(shape)
            .background(
                if (selected) Brush.linearGradient(
                    listOf(Palette.Aqua.copy(alpha = 0.45f), Palette.Violet.copy(alpha = 0.45f))
                ) else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))
            )
            .glass(shape, if (selected) 0.6f else 1f)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
    )
}

private val avatarPalette = listOf(
    listOf(Color(0xFF3DE0D0), Color(0xFF2B7BFF)),
    listOf(Color(0xFF7B5CFF), Color(0xFFFF6B9A)),
    listOf(Color(0xFFFFB86B), Color(0xFFFF6B9A)),
    listOf(Color(0xFF6BFFB0), Color(0xFF3DB0E0)),
    listOf(Color(0xFFB06BFF), Color(0xFF3D6BE0)),
)

@Composable
private fun ChatRow(chat: Chat) {
    Row(
        Modifier
            .fillMaxWidth()
            .glass(RoundedCornerShape(26.dp))
            .clickable { /* екран чату — наступний етап */ }
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Avatar(chat)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                chat.title, color = Palette.Text, fontSize = 17.sp,
                fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(2.dp))
            Text(
                chat.lastMessage, color = Palette.TextDim, fontSize = 14.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.width(10.dp))
        Column(horizontalAlignment = Alignment.End) {
            Text(chat.time, color = Palette.TextDim, fontSize = 12.sp)
            Spacer(Modifier.height(6.dp))
            if (chat.unread > 0) {
                Text(
                    chat.unread.toString(),
                    color = if (chat.muted) Palette.Text else Palette.Ink,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(if (chat.muted) Color.White.copy(alpha = 0.22f) else Palette.Aqua)
                        .padding(horizontal = 8.dp, vertical = 2.dp),
                )
            } else {
                Spacer(Modifier.height(18.dp))
            }
        }
    }
}

@Composable
private fun Avatar(chat: Chat) {
    val colors = avatarPalette[(chat.id % avatarPalette.size).toInt()]
    val initials = chat.title.split(" ")
        .filter { it.isNotBlank() }
        .take(2)
        .joinToString("") { it.first().uppercase() }
    Box(
        Modifier
            .size(52.dp)
            .clip(CircleShape)
            .background(Brush.linearGradient(colors)),
        contentAlignment = Alignment.Center,
    ) {
        Text(initials, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}
