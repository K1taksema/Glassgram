package app.tgglass.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Palette {
    val Ink = Color(0xFF080D1C)
    val Aqua = Color(0xFF3DE0D0)
    val Violet = Color(0xFF7B5CFF)
    val Rose = Color(0xFFFF6B9A)
    val Text = Color(0xFFF2F5FF)
    val TextDim = Color(0xFFF2F5FF).copy(alpha = 0.68f)
}

@Composable
fun GlassTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Palette.Aqua,
            background = Palette.Ink,
            surface = Palette.Ink,
            onBackground = Palette.Text,
            onSurface = Palette.Text,
        ),
        content = content,
    )
}
