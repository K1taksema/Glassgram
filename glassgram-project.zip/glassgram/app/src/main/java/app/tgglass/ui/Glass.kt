package app.tgglass.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Rim = Brush.linearGradient(
    listOf(Color.White.copy(alpha = 0.75f), Color.White.copy(alpha = 0.06f), Color.White.copy(alpha = 0.30f))
)

/** «Рідке скло»: матова заливка зі світлим бліком зверху та яскравим краєм. */
fun Modifier.glass(shape: Shape, strength: Float = 1f): Modifier = this
    .clip(shape)
    .background(
        Brush.verticalGradient(
            listOf(
                Color.White.copy(alpha = 0.20f * strength),
                Color.White.copy(alpha = 0.07f * strength),
            )
        )
    )
    .border(1.dp, Rim, shape)

/** Темне тло з трьома розмитими плямами, що повільно пливуть під склом. */
@Composable
fun LiquidBackground(content: @Composable BoxScope.() -> Unit) {
    val t = rememberInfiniteTransition(label = "drift")
    val a by t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(22000, easing = LinearEasing), RepeatMode.Reverse),
        label = "a",
    )
    val b by t.animateFloat(
        1f, 0f,
        infiniteRepeatable(tween(28000, easing = LinearEasing), RepeatMode.Reverse),
        label = "b",
    )
    Box(Modifier.fillMaxSize().background(Palette.Ink)) {
        Canvas(Modifier.fillMaxSize().blur(48.dp, BlurredEdgeTreatment.Unbounded)) {
            val w = size.width
            val h = size.height
            drawCircle(
                Palette.Violet.copy(alpha = 0.75f), radius = w * 0.55f,
                center = Offset(w * (0.15f + 0.5f * a), h * (0.18f + 0.12f * b)),
            )
            drawCircle(
                Palette.Aqua.copy(alpha = 0.60f), radius = w * 0.50f,
                center = Offset(w * (0.90f - 0.5f * b), h * (0.55f + 0.15f * a)),
            )
            drawCircle(
                Palette.Rose.copy(alpha = 0.55f), radius = w * 0.45f,
                center = Offset(w * (0.20f + 0.4f * b), h * (0.95f - 0.2f * a)),
            )
        }
        content()
    }
}

@Composable
fun GlassOrb(modifier: Modifier = Modifier) {
    Box(modifier.size(104.dp).glass(CircleShape, 1.3f), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(52.dp)) {
            val w = size.width
            val h = size.height
            val plane = Path().apply {
                moveTo(w * 0.04f, h * 0.48f)
                lineTo(w * 0.96f, h * 0.08f)
                lineTo(w * 0.68f, h * 0.92f)
                lineTo(w * 0.46f, h * 0.60f)
                close()
            }
            drawPath(plane, Color.White.copy(alpha = 0.95f))
            drawLine(
                Palette.Ink.copy(alpha = 0.35f),
                Offset(w * 0.46f, h * 0.60f), Offset(w * 0.96f, h * 0.08f),
                strokeWidth = 2.dp.toPx(),
            )
        }
    }
}

@Composable
fun GlassField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    keyboardType: KeyboardType = KeyboardType.Text,
    visual: VisualTransformation = VisualTransformation.None,
    imeAction: ImeAction = ImeAction.Done,
    onDone: () -> Unit = {},
) {
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = true,
        textStyle = TextStyle(color = Palette.Text, fontSize = 18.sp),
        cursorBrush = SolidColor(Palette.Aqua),
        visualTransformation = visual,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType, imeAction = imeAction),
        keyboardActions = KeyboardActions(onAny = { onDone() }),
        modifier = modifier
            .fillMaxWidth()
            .glass(RoundedCornerShape(20.dp))
            .padding(horizontal = 20.dp, vertical = 16.dp),
        decorationBox = { inner ->
            Box {
                if (value.isEmpty()) {
                    Text(placeholder, color = Palette.TextDim, fontSize = 18.sp)
                }
                inner()
            }
        },
    )
}

@Composable
fun GlassButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    loading: Boolean = false,
) {
    val shape = RoundedCornerShape(24.dp)
    Box(
        modifier
            .fillMaxWidth()
            .alpha(if (enabled) 1f else 0.5f)
            .clip(shape)
            .background(
                Brush.linearGradient(
                    listOf(Palette.Aqua.copy(alpha = 0.55f), Palette.Violet.copy(alpha = 0.55f))
                )
            )
            .border(1.dp, Rim, shape)
            .clickable(enabled = enabled && !loading, onClick = onClick)
            .padding(vertical = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        if (loading) {
            CircularProgressIndicator(Modifier.size(22.dp), color = Palette.Text, strokeWidth = 2.dp)
        } else {
            Text(text, color = Palette.Text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}
