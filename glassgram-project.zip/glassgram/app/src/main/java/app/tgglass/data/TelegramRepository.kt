package app.tgglass.data

import kotlinx.coroutines.flow.StateFlow

sealed interface AuthState {
    data object Phone : AuthState
    data class Code(val phone: String) : AuthState
    data object Password : AuthState
    data object Ready : AuthState
}

data class Chat(
    val id: Long,
    val title: String,
    val lastMessage: String,
    val time: String,
    val unread: Int = 0,
    val muted: Boolean = false,
    val pinned: Boolean = false,
)

/**
 * Єдина точка доступу до Telegram. Зараз працює демо-реалізація;
 * справжня (TDLib) підключається тут же, UI змінювати не потрібно.
 */
interface TelegramRepository {
    val authState: StateFlow<AuthState>
    val chats: StateFlow<List<Chat>>

    suspend fun submitPhone(phone: String): Result<Unit>
    suspend fun submitCode(code: String): Result<Unit>
    suspend fun submitPassword(password: String): Result<Unit>
    fun logOut()
}
