package app.tgglass.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.tgglass.data.FakeTelegramRepository
import app.tgglass.data.TelegramRepository
import kotlinx.coroutines.launch

class AppViewModel : ViewModel() {
    // Тут підміняється реалізація: FakeTelegramRepository -> TdLibTelegramRepository
    private val repo: TelegramRepository = FakeTelegramRepository()

    val auth = repo.authState
    val chats = repo.chats

    var busy by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    fun submitPhone(phone: String) = launchStep { repo.submitPhone(phone) }
    fun submitCode(code: String) = launchStep { repo.submitCode(code) }
    fun submitPassword(password: String) = launchStep { repo.submitPassword(password) }
    fun logOut() = repo.logOut()

    private fun launchStep(block: suspend () -> Result<Unit>) {
        if (busy) return
        viewModelScope.launch {
            busy = true
            error = null
            block().onFailure { error = it.message ?: "Щось пішло не так. Спробуйте ще раз" }
            busy = false
        }
    }
}
