package app.tgglass.data

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class FakeTelegramRepository : TelegramRepository {
    private val _auth = MutableStateFlow<AuthState>(AuthState.Phone)
    override val authState: StateFlow<AuthState> = _auth.asStateFlow()

    private val _chats = MutableStateFlow<List<Chat>>(emptyList())
    override val chats: StateFlow<List<Chat>> = _chats.asStateFlow()

    override suspend fun submitPhone(phone: String): Result<Unit> {
        delay(600)
        val digits = phone.count { it.isDigit() }
        if (digits < 9) {
            return Result.failure(IllegalArgumentException("Номер закороткий. Приклад: +380501234567"))
        }
        _auth.value = AuthState.Code(phone)
        return Result.success(Unit)
    }

    override suspend fun submitCode(code: String): Result<Unit> {
        delay(600)
        if (code != "12345") {
            return Result.failure(IllegalArgumentException("Невірний код. У демо-режимі це 12345"))
        }
        _chats.value = sampleChats
        _auth.value = AuthState.Ready
        return Result.success(Unit)
    }

    override suspend fun submitPassword(password: String): Result<Unit> {
        delay(600)
        _chats.value = sampleChats
        _auth.value = AuthState.Ready
        return Result.success(Unit)
    }

    override fun logOut() {
        _chats.value = emptyList()
        _auth.value = AuthState.Phone
    }

    private val sampleChats = listOf(
        Chat(1, "Збережені", "Список покупок на вихідні", "12:40", pinned = true),
        Chat(2, "Мама", "Передзвони, коли будеш вільний", "12:31", unread = 2, pinned = true),
        Chat(3, "Команда дизайну", "Олена: оновила макети екрана входу", "11:58", unread = 14),
        Chat(4, "Андрій Коваль", "Дякую, отримав!", "11:20"),
        Chat(5, "Kotlin Ukraine", "Вийшов новий реліз Compose, дивіться нотатки", "10:05", unread = 58, muted = true),
        Chat(6, "Софія", "Фото з поїздки вже в альбомі", "09:47", unread = 1),
        Chat(7, "Доставка", "Кур'єр буде за 10 хвилин", "Вчора"),
        Chat(8, "Робочий чат", "Максим: зустріч перенесли на 15:00", "Вчора", muted = true),
        Chat(9, "Ігор Мельник", "Голосове повідомлення", "Пн"),
        Chat(10, "Новини тижня", "Підсумки: головне за сім днів", "Пн", unread = 5, muted = true),
        Chat(11, "Оля", "Чекаю на тебе біля входу", "Нд"),
        Chat(12, "Бібліотека", "Книжку можна забрати до п'ятниці", "Сб"),
    )
}
